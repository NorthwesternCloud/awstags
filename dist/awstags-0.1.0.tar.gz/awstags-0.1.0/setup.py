# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['awstags']

package_data = \
{'': ['*']}

install_requires = \
['boto3>=1.16.13,<2.0.0', 'docopt>=0.6.2,<0.7.0']

entry_points = \
{'console_scripts': ['dc2csv = awstags.res2csv:main']}

setup_kwargs = {
    'name': 'awstags',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'David Schober',
    'author_email': 'davidschob@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
